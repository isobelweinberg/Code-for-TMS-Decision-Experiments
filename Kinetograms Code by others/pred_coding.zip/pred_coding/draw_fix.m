function draw_fix(x,y,w,col) % position, width, colour
cgpencol(col);
cgrect(x,y,w,w);